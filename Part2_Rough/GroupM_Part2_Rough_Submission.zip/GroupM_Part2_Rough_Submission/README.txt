National Income Dynamics Study-Coronavirus Rapid Mobile Survey (NIDS-CRAM)

Part 2 Rough Draft

Group M

Dino Anastasopoulos: 1900661
Brenton Budler: 1827655
Philani Mpofu: 1848751

1) Our folder consists of two subfolders, firsly "Notebook" which contains our Jupyter Notebook and the .csv files that are necessary to run the code, and secondly "HTML" which contains the contents as described below.

2) It was requested that we implement a button to toggle between showing/hiding the code. This was implemented using nbconvert. 
We have submitted two .html files, namely GroupM_Part2_Rough_WithCode.html and GroupM_Part2_Rough_WithoutCode.html, and each of them has a corresponding folder of other files necessary for the HTML to load correctly.
The purpose of this is so that the marker can view our project with the input blocks(code) either hidden or showing, without having to install nbconvert on their machines.